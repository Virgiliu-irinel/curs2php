<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masini</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
</head>
<?php include_once("head.php"); ?>
<?php include_once('connect.php'); ?>
<?php
$sql = "SELECT * FROM masini ";
$result = mysqli_query($con, $sql);
if (mysqli_num_rows($result) > 0) : ?>

    <body>
        <div class="container">
            <h1 class="h1">
                Lista Masini
            </h1>
            <?php //include_once('array.php');
            ?>
            <?php //print_r($masini);
            ?>
            <table class="table table-dark">
                <thead>
                    <tr>
                        <th scope="col">Nume</th>
                        <th scope="col">Model</th>
                        <th scope="col">Pret</th>
                        <th scope="col">An</th>
                        <th scope="col">Culoare</th>
                        <th scope="col">Poza</th>
                        <th scope="col">Data Adaugare</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($masina = mysqli_fetch_assoc($result)) : ?>
                        <?php if ($masina['an'] >= 2000) : ?>
                            <tr>
                                <th scope="row"><?php echo ucfirst($masina['nume']); ?></th>
                                <td><?php echo ucfirst($masina['model']); ?></td>
                                <td><?php echo $masina['pret']; ?></td>
                                <td><?php echo $masina['an']; ?></td>
                                <td><?php echo ucfirst($masina['culoare']); ?></td>
                                <td><img style="max-width:80px;" src="<?php echo $masina['poza']; ?>" alt="poza"></td>
                                <td><?php echo $masina['dataadaugare']; ?></td>

                            </tr>
                        <?php endif; ?>
                    <?php endwhile; ?>

                </tbody>
            </table>
        <?php endif; ?>
        </div>
    </body>

</html>