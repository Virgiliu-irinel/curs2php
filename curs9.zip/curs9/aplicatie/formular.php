<!DOCTYPE html>
<html lang="en">
<?php include_once("head.php"); ?>

<body>
    <div class="container">
        <h1 class="h1">
            Formular adaugare masini
        </h1>
        <form action="masini.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="nume">Nume</label>
                <input name="nume" class="form-control" id="nume" type="text">
                
            </div>
            <div class="form-group">
                <label for="model">Model</label>
                <input name="model" class="form-control" id="model" type="text">
            </div>
            <div class="form-group">
                <label for="pret">Pret</label>
                <input name="pret" class="form-control" id="pret" type="text">
            </div>
            <div class="form-group">
                <label for="an">An</label>
                <input  name="an" class="form-control" id="an" type="text">
            </div>
            <div class="form-group">
                <label for="culoare">Culoare</label>
                <input  name="culoare" class="form-control" id="culoare" type="text">
            </div>
            <div class="form-group">
                <label for="poza">Poza</label>
                <input name="poza" class="form-control"  type="file">
            </div>


            <button type="submit" class="btn btn-primary">Salveaza masina</button>
        </form>
    </div>
</body>

</html>