<?php


$masini=[
    ['nume'=>'mercedes','model'=>'c200','pret'=>'30000','an'=>'2020','culoare'=>'gri','poza'=>'img4.jpg','dataadaugare'=>'2021-01-19'],
    ['nume'=>'audi','model'=>'Q1','pret'=>'10000','an'=>'2015','culoare'=>'alb','poza'=>'img1.jpg','dataadaugare'=>'2021-01-19'],
    ['nume'=>'bmw','model'=>'x1','pret'=>'15000','an'=>'2018','culoare'=>'negru','poza'=>'img2.jpg','dataadaugare'=>'2021-01-19'],
    ['nume'=>'dacia','model'=>'logan','pret'=>'7000','an'=>'2019','culoare'=>'galben','poza'=>'img3.jpg','dataadaugare'=>'2021-01-19'],
    

];

usort($masini,function($a,$b){
    return strcasecmp ($a['nume'] , $b['nume']);
});



?>