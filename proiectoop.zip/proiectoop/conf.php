<?php
 $GLOBALS['base'] ='http://localhost/cursphp/proiectoop/';

 ?>