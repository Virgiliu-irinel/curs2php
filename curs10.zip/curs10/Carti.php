<?php
class Carti{
    public $titlu ='Demo';
    public $autor = 'Mihai';
    public $editura = '';
    public $an_aparitie='';
    public $nr_pagini='';
    public $pret='';
    public static $format='A4';

    public function info($an){
        echo 'Aceasta carte se numeste '.$this->titlu;
    }
    public function stopCitit(){
        echo "nu mai citesc";
        $this->info($this->an_aparitie);
    }


}





?>