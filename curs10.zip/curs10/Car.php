<?php
class Car{

    public $make;
    public $model;
    public $doors;
    public static $wheels=4;
}


?>