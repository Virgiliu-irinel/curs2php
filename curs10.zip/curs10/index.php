<?php
//include_once ('Car.php');
include_once ('Carti.php');

// $masina = new Car();
// $masina2 = new Car();
// $masina->model='Logan';
// echo Car::$wheels;
// echo $masina::$wheels;

// echo "<pre>";
// var_dump($masina2);
// echo "<pre>";
// var_dump($masina);
// echo"<pre>";

$carte = new Carti();
$carte2 = new Carti;

$carte->titlu='Poezii';
$carte->autor='Mihai Eminescu';
$carte->editura='Humanitas';
$carte->an_aparitie='2013';
$carte->nr_pagini='340';
$carte->pret='100';

$carte2->titlu='Povesti';
$carte2->autor='Ion Creanga';
$carte2->editura='Iris';
$carte2->an_aparitie='1999';
$carte2->nr_pagini='400';
$carte2->pret='123';
$carte2->info(2021);

$carte3 = clone $carte2;
$carte3->titlu='titlu de la carte 3';
echo "<pre>";
var_dump($carte3);


echo "<pre>";
var_dump($carte);
echo "<br>";
var_dump($carte2);
$carte2->stopCitit();
$carte3->stopCitit();

