<h1>
continut incarcat din fisierul teste.php
</h1>
<?php
$x=150;
?>