<?php

// $a = false;
// if(!$a==($b=!false)) echo "Salut";


// $x = false;
// $a = (
//     (2+3)==5 && 
//     (true == -25) || 
//     $x == true);
// var_dump( $a);


// $i = 25;
// if($i==1) echo "Hello";
// else if($i=2) echo "Hello World";
// else if($i==25) echo "Hello World and Goodbye";
// else "Error";

// $x = 10;
// if($x==25); { echo "x este 25";}

// $a = array('a', 3 => 'b', 1 => 'c', 'd');

// echo $a[4];


include('teste.php');

echo $test;

echo 33;
?>


