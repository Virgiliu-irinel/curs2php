<?php
echo "pas1";
echo "<br>";
include_once "teste.php";
echo "pas2";
echo "<br>";
include_once "teste.php";
echo $x;




?>